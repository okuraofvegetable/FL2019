p(a).
q(b).