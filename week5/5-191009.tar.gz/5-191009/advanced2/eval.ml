open Syntax

exception Unbound

type env = (name * value) list

let empty_env = []
let extend x v env = (x, v) :: env

let rec lookup x env =
  try List.assoc x env with Not_found -> raise Unbound

exception EvalErr
exception DivisionByZero

let rec eval_expr env e =
  match e with
  | EConstInt i ->
    VInt i
  | EConstBool b ->
    VBool b
  | EVar x ->
    (try
       lookup x env
     with
     | Unbound -> raise EvalErr)
  | EAdd (e1,e2) ->
    let v1 = eval_expr env e1 in
    let v2 = eval_expr env e2 in
    (match v1, v2 with
     | VInt i1, VInt i2 -> VInt (i1 + i2)
     | _ -> raise EvalErr)
  | ESub (e1,e2) ->
    let v1 = eval_expr env e1 in
    let v2 = eval_expr env e2 in
    (match v1, v2 with
     | VInt i1, VInt i2 -> VInt (i1 - i2)
     | _ -> raise EvalErr)
  | EMul (e1,e2) ->
    let v1 = eval_expr env e1 in
    let v2 = eval_expr env e2 in
    (match v1, v2 with
     | VInt i1, VInt i2 -> VInt (i1 * i2)
     | _ -> raise EvalErr)
  | EDiv (e1,e2) ->
    let v1 = eval_expr env e1 in
    let v2 = eval_expr env e2 in
    (match v1, v2 with
     | VInt i1, VInt i2 -> (match i2 with
                            | 0 -> (raise DivisionByZero)
                            | i2 -> VInt (i1 / i2))
     | _ -> raise EvalErr)
  | EEq (e1,e2) ->
    let v1 = eval_expr env e1 in
    let v2 = eval_expr env e2 in
    (match v1, v2 with
     | VInt i1,  VInt i2  -> VBool (i1 = i2)
     | _ -> raise EvalErr)
  | ELt (e1,e2) ->
    let v1 = eval_expr env e1 in
    let v2 = eval_expr env e2 in
    (match v1, v2 with
     | VInt i1,  VInt i2  -> VBool (i1 < i2)
     | _ -> raise EvalErr)
  | EIf (e1,e2,e3) ->
    let v1 = eval_expr env e1 in
    (match v1 with
     | VBool b ->
       if b then eval_expr env e2 else eval_expr env e3
     | _ -> raise EvalErr)
  | ELet (n,e1,e2) -> (eval_expr (extend n (eval_expr env e1) env) e2)
  | EAnd (e1,e2) ->
    let v1 = eval_expr env e1 in
    let v2 = eval_expr env e2 in
    (match v1,v2 with
     | VBool b1, VBool b2 -> VBool (b1 && b2)
     | _ -> raise EvalErr)
  | EOr (e1,e2) ->
    let v1 = eval_expr env e1 in
    let v2 = eval_expr env e2 in
    (match v1,v2 with
     | VBool b1, VBool b2 -> VBool (b1 || b2)
     | _ -> raise EvalErr)
  | EXor (e1,e2) ->
    let v1 = eval_expr env e1 in
    let v2 = eval_expr env e2 in
    (match v1,v2 with
     | VBool b1, VBool b2 -> VBool (((not b1)&&b2)||(b1&&(not b2)))
     | _ -> raise EvalErr)
let rec fold_left = fun f e l ->
  match l with
  | [] -> e
  | x::xs -> fold_left f (f e x) xs;;
let rec eval_lets_sub s x = 
  match s with
  | (msg,env,prev) -> 
    (match x with 
     | (n,e) -> 
      (match (eval_command env (CDecl (n,e))) with
       | (m,newenv,v) -> 
        (match prev with
         | ("",_) -> (msg,newenv,(n,v))
         | (prevname,prevvalue) -> (msg^"val "^prevname^" = "^(string_of_value prevvalue)^"\n",newenv,(n,v)))))
and eval_command env c =
  match c with
  | CExp e -> ("-", env, eval_expr env e)
  | CDecl (n,e) -> (match (eval_expr env e) with
                    | v -> ("val "^n,(extend n v env),v)) 
  | CDecls ds -> (match (fold_left eval_lets_sub ("",env,("",(VInt 0))) ds) with
                  | (msg,newenv,(prevname,prevvalue)) -> (msg^"val "^prevname,newenv,prevvalue))